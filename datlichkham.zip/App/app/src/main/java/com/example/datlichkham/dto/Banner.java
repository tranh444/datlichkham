package com.example.datlichkham.dto;

public class Banner {
    int resourceId;

    public Banner(int resourceId) {
        this.resourceId = resourceId;
    }

    public int getResourceId() {
        return resourceId;
    }

    public void setResourceId(int resourceId) {
        this.resourceId = resourceId;
    }
}
